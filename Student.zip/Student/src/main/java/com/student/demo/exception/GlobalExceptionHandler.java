package com.student.demo.exception;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler{
	@ExceptionHandler
public ResponseEntity<?> constrantVialationExceptionHandler(SQLIntegrityConstraintViolationException ex){
	return new ResponseEntity<>("Already existes",HttpStatus.BAD_REQUEST);
	
}
}
