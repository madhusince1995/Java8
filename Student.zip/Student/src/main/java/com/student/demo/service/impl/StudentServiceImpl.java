package com.student.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.student.demo.model.Student;
import com.student.demo.repository.StudentRepository;

@Service
public class StudentServiceImpl  {
	@Autowired
	private StudentRepository studentRepository;

	public  Student save(Student entity) {
		
		return studentRepository.save(entity);
	}

	public List<Student> findAll(Sort sort) {
		return studentRepository.findAll(sort);
	}

	public Optional<Student> findById(Integer id) {
		return studentRepository.findById(id);
	}

	public void deleteById(Integer id) {
		studentRepository.deleteById(id);
	}

	/*
	 * public Student getById(Integer id) { return studentRepository.getById(id); }
	 */

	

}
