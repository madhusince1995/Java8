package com.student.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.demo.model.Student;
import com.student.demo.service.impl.StudentServiceImpl;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentService;

	@PostMapping("/save")
	public Student save(@RequestBody Student entity) {
		return studentService.save(entity);
	}

	@GetMapping("/getAll")
	public List<Student> findAll(Sort sort) {
		return studentService.findAll(sort);
	}

	@GetMapping("/getAll/{id}")
	public Optional<Student> findById(@PathVariable("id") Integer id) {
		return studentService.findById(id);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable("id") Integer id) {
		studentService.deleteById(id);
	}
	/*
	 * @GetMapping("/getby/{id}") public Student getById(@PathVariable("id") Integer
	 * id) { return studentService.getById(id); }
	 */

}
